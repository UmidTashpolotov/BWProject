#include<iostream>
#include<string>
#include<cmath>
using namespace std;

int main()
{
class game; //The class/variable that we can use to organize our code of the game and then initiate the first level through the do-while statement.
class Char_Move; //The class we can use to store our code for the character movement
class Fst_Level; //The class we can use to store the code for our first level 
{
  int choice; // This first do while statement allows the player to start playing or exit the game. 
 
  do
  {
   cout << "Press 1 to Start or 0 to Quit Game " << endl;
   cin >> choice; 

   switch(choice)
  {
    case 0:
      cout << "Thanks for Playing!";
      return 0; //After the value of 0 is entered, the game will exit. 
      
    case 1:
      cout << "Let's Play! " << endl;
      cout << game; 
      break; //This engages the player into the game, and after we finish actually making all the code for the game we will be able to have the player loop back to the main menu once the game is finished. 
  }
  }
  while(choice != 0);

}
}