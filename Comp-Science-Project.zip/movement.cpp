#include<iostream>
#include<string>
#include<cmath>
using namespace std;

int main()
{
   int movement
    
    while(movement = d)
    {
      cout << x++ 1 
    }
    
}